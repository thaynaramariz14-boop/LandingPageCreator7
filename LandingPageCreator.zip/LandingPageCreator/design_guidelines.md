# Design Guidelines: Christmas Recipe E-book Landing Page

## Design Approach
**Reference-Based Approach**: Elegant Christmas marketing page inspired by the provided e-book screenshots, combining festive aesthetics with modern web design patterns similar to premium product landing pages (think Gumroad, ConvertKit landing pages for digital products).

## Visual Identity
**Color Palette**: Christmas elegance theme
- Primary: Festive red (#C41E3A or similar deep red)
- Accent: Luxurious gold (#D4AF37, #FFD700)
- Supporting: Pure white (#FFFFFF), Christmas green (#165B33)
- Effects: Soft golden bokeh lights, subtle sparkles

**Typography**:
- Headings: Serif font (Playfair Display or Cormorant Garamond) for elegant, traditional feel
- Body: Clean sans-serif (Montserrat or Open Sans) for readability
- Hierarchy: Large hero titles (48-64px), section headers (32-40px), body text (16-18px)

## Layout System
**Spacing**: Use Tailwind units of 4, 6, 8, 12, 16, 20, 24, 32 for consistent rhythm
**Container**: max-w-7xl for main content, max-w-6xl for text-heavy sections
**Vertical rhythm**: py-16 to py-24 for section spacing on desktop, py-12 on mobile

## Page Structure (7 Required Sections)

### 1. Hero Section
- Full viewport height with red gradient background
- Golden bokeh light effects overlaying background (CSS gradient circles with blur)
- Center-aligned content with prominent serif title "50 Receitas Natalinas"
- Compelling subtitle about the e-book
- Large gold CTA button: "Quero meu E-book" with hover glow effect
- Background should include Christmas dinner imagery and Santa Claus illustration

### 2. "O que você vai receber" (What You'll Receive)
- White content card with soft shadows and rounded corners
- Christmas decorative elements: ribbons, lights, pine branches as borders/accents
- Clean layout inspired by the e-book's table of contents design
- Brief explanatory text with visual hierarchy

### 3. Content Preview Section
- 2-3 recipe preview cards mimicking e-book interior pages
- Each card: white background, green ribbon accent bar, recipe photo
- Red recipe titles, golden "Ingredientes" (Ingredients) boxes
- Professional styling with soft shadows and clean borders
- Grid layout: 2 columns on desktop, stack on mobile

### 4. Benefits Section
- Bullet points with Christmas-themed icons (subtle, elegant)
- List items:
  - Traditional and gourmet recipes
  - Perfect for selling or preparing Christmas dinner
  - Photos and detailed step-by-step instructions
  - Beginner-friendly
  - Vegan, sweet, and savory options
- White cards with green/gold accents

### 5. Bonus Offer Highlight
- Distinctive golden bordered section
- Emphasis on exclusive bonus: "Mini e-book Embalagens Natalinas Profissionais"
- Starburst or badge graphic element for "BÔNUS"

### 6. Pricing/CTA Section
- Red background with golden decorative borders
- Large price display with original/discounted pricing
- "7-day guarantee" trust badge
- Prominent CTA button: "Quero garantir agora!" (gold with glow)
- Urgency/scarcity elements if applicable

### 7. Footer
- Red background with subtle sparkle effects
- Small Santa illustration in corner
- Contact information, terms, privacy policy links
- Kept minimal and festive

## Component Library

**Buttons**:
- Primary (Gold): Large, rounded, with subtle shadow and glow effect on hover
- White text, semi-bold weight
- Implement blur backdrop when placed over images

**Cards**:
- Soft rounded corners (12-16px border radius)
- Subtle shadows (shadow-lg)
- White backgrounds with optional gold/green accent borders
- Generous internal padding (p-8)

**Decorative Elements**:
- Golden bokeh circles (various sizes, blurred)
- String lights effect (small golden dots)
- Pine branch illustrations (SVG or icon fonts)
- Ribbon banners (CSS shapes or subtle images)

**Icons**: Use Heroicons or Font Awesome Christmas-themed icons (gifts, stars, snowflakes, trees) - keep them subtle and elegant, not cartoonish

## Images
**Large Hero Image**: Yes - Full-width background featuring Christmas dinner table with festive decorations and Santa Claus character
**Recipe Preview Images**: 2-3 high-quality food photography images showing prepared Christmas dishes
**Decorative Graphics**: Small Santa illustration for footer, optional pine branches/ornaments as section dividers

## Responsive Behavior
- Mobile-first approach
- Hero: Stack content vertically, reduce title size
- Cards: Single column on mobile, 2-3 columns on desktop
- Preserve festive visual effects across all breakpoints
- Touch-friendly buttons (min 44px height)

## Animation
- Subtle entrance animations for section reveals (fade + slide up)
- Bokeh lights gentle floating motion (optional, very subtle)
- Button hover states with glow intensification
- NO aggressive or distracting animations - maintain elegance

## Accessibility
- High contrast between text and backgrounds
- Focus states for all interactive elements
- Semantic HTML structure
- Alt text for all decorative and content images