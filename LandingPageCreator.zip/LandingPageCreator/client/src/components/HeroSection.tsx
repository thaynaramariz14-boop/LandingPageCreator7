import { Button } from "@/components/ui/button";
import heroImage from "@assets/generated_images/53_Receitas_Natalinas_ebook_cover_e67866bb.png";

export default function HeroSection() {
  const handleCTA = () => {
    const pricingSection = document.getElementById('pricing');
    pricingSection?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-screen flex items-end justify-center overflow-hidden pb-20">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${heroImage})`,
        }}
      />
      
      <div className="relative z-10 container mx-auto px-4 text-center">
        <Button 
          size="lg"
          className="bg-accent text-accent-foreground hover:bg-accent border-accent-border text-xl px-12 py-7 shadow-2xl font-bold"
          onClick={handleCTA}
          data-testid="button-hero-cta"
        >
          QUERO MEU EBOOK
        </Button>
      </div>
    </section>
  );
}
