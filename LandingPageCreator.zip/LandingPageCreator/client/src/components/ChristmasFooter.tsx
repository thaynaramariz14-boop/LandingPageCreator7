import santaImage from "@assets/generated_images/Santa_footer_decoration_7cdde83c.png";

export default function ChristmasFooter() {
  return (
    <footer className="bg-primary text-primary-foreground relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-20">
        <div className="absolute top-5 left-20 w-24 h-24 bg-accent rounded-full blur-2xl animate-pulse" />
        <div className="absolute bottom-10 right-32 w-32 h-32 bg-accent rounded-full blur-2xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 w-20 h-20 bg-accent rounded-full blur-2xl animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      <div className="container mx-auto px-4 py-12 relative z-10">
        <div className="grid md:grid-cols-2 gap-8 mb-8 max-w-3xl mx-auto">
          <div>
            <h3 className="font-serif text-2xl font-bold mb-4">53 Receitas Natalinas</h3>
            <p className="text-primary-foreground/80">
              Seu guia completo para um Natal inesquecível
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Legal</h4>
            <ul className="space-y-2 text-primary-foreground/80">
              <li>
                <a href="#" className="hover-elevate px-2 py-1 rounded inline-block" data-testid="link-terms">
                  Termos de Uso
                </a>
              </li>
              <li>
                <a href="#" className="hover-elevate px-2 py-1 rounded inline-block" data-testid="link-privacy">
                  Política de Privacidade
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-primary-foreground/80 text-sm">
            © 2025 53 Receitas Natalinas. Todos os direitos reservados.
          </p>
          
          <div className="w-20 h-20">
            <img 
              src={santaImage} 
              alt="Santa Claus" 
              className="w-full h-full object-contain opacity-90"
              data-testid="img-santa"
            />
          </div>
        </div>
      </div>
    </footer>
  );
}
