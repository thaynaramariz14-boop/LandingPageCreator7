import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function FAQ() {
  const faqs = [
    {
      question: "O e-book tem realmente 53 receitas? Ou são só algumas e o resto é básico?",
      answer: "Sim! O e-book contém 53 receitas completas, detalhadas e testadas, todas natalinas. São pratos variados: doces, salgados, sobremesas, acompanhamentos e até versões veganas. Nada de receita repetida ou básica — são pratos selecionados para deixar sua ceia inesquecível ou para você lucrar no Natal.",
      author: "Maria Eduarda"
    },
    {
      question: "Depois que eu pagar, quanto tempo demora para eu receber o e-book?",
      answer: "A entrega é imediata! Assim que o pagamento é confirmado, você recebe automaticamente o link para baixar o e-book no seu e-mail. Em poucos segundos já pode acessar tudo no celular, computador ou tablet.",
      author: "Juliana Santos"
    },
    {
      question: "Eu posso usar as receitas para vender e ganhar dinheiro no Natal?",
      answer: "Com certeza! O e-book foi pensado inclusive para quem quer lucrar no Natal. As receitas são perfeitas para vendas, e muitas têm grande procura nessa época — como rabanadas, bolos natalinos, panetones, sobremesas gourmet e ceias completas.",
      author: "Larissa Gomes"
    }
  ];

  return (
    <section className="py-20 bg-card">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <h2 
              className="font-serif text-4xl md:text-5xl font-bold text-primary mb-4"
              data-testid="text-faq-title"
            >
              Perguntas Frequentes
            </h2>
            <p className="text-lg text-muted-foreground">
              Tire suas dúvidas sobre o e-book
            </p>
          </div>

          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                data-testid={`faq-item-${index}`}
              >
                <AccordionTrigger className="text-left">
                  <span className="font-semibold">{faq.question}</span>
                </AccordionTrigger>
                <AccordionContent>
                  <p className="text-muted-foreground leading-relaxed">
                    {faq.answer}
                  </p>
                  <p className="text-sm text-muted-foreground/70 mt-3 italic">
                    — {faq.author}
                  </p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
