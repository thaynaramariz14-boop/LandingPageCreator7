import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Star } from "lucide-react";

export default function PricingCTA() {
  const handlePurchase = () => {
    console.log('Purchase initiated');
    alert('Em breve você será redirecionado para o checkout!');
  };

  return (
    <section className="py-20 bg-primary relative overflow-hidden" id="pricing">
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-30">
        <div className="absolute top-10 left-10 w-40 h-40 bg-accent rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-10 w-48 h-48 bg-accent rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 w-32 h-32 bg-accent rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-2xl mx-auto text-center mb-12">
          <h2 
            className="font-serif text-4xl md:text-5xl font-bold text-primary-foreground mb-4"
            data-testid="text-pricing-title"
          >
            Oferta Especial de Natal
          </h2>
          <p className="text-xl text-primary-foreground/90">
            Garanta agora seu acesso completo
          </p>
        </div>

        <Card className="max-w-lg mx-auto p-8 md:p-12 text-center shadow-2xl">
          <Badge 
            className="mb-6 text-base px-4 py-1 bg-primary text-primary-foreground"
            data-testid="badge-discount"
          >
            <Star className="w-4 h-4 mr-1 inline fill-current" />
            Promoção por Tempo Limitado
          </Badge>

          <div className="mb-8">
            <p className="text-muted-foreground line-through text-2xl mb-2">
              De R$ 97,00
            </p>
            <p className="text-5xl md:text-6xl font-bold text-primary mb-2">
              R$ 9
              <span className="text-2xl">,99</span>
            </p>
            <p className="text-muted-foreground">
              Pagamento único • Acesso imediato
            </p>
          </div>

          <Button 
            size="lg"
            onClick={handlePurchase}
            className="w-full text-xl py-6 mb-6 bg-accent text-accent-foreground hover:bg-accent border-accent-border shadow-lg"
            data-testid="button-purchase"
          >
            Quero garantir agora!
          </Button>

          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
            <Shield className="w-5 h-5 text-[#165B33]" />
            <span>Garantia de 7 dias ou seu dinheiro de volta</span>
          </div>
        </Card>
      </div>
    </section>
  );
}
