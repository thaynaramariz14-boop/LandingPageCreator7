import { Card } from "@/components/ui/card";
import { Sparkles, BookOpen, ChefHat, Gift } from "lucide-react";

export default function WhatYouReceive() {
  const features = [
    {
      icon: BookOpen,
      title: "53 Receitas Completas",
      description: "Receitas tradicionais e gourmet com instruções detalhadas"
    },
    {
      icon: ChefHat,
      title: "Passo a Passo Ilustrado",
      description: "Fotos profissionais e guia completo para cada receita"
    },
    {
      icon: Sparkles,
      title: "Receitas Variadas",
      description: "Doces, salgados, veganas e opções para todos os gostos"
    }
  ];

  return (
    <section className="py-20 bg-background" id="what-you-receive">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 
            className="font-serif text-4xl md:text-5xl font-bold text-primary mb-4"
            data-testid="text-section-title"
          >
            O que você vai receber
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Um guia completo para criar a ceia de Natal perfeita
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {features.map((feature, index) => (
            <Card 
              key={index}
              className="p-6 text-center hover-elevate"
              data-testid={`card-feature-${index}`}
            >
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                <feature.icon className="w-8 h-8 text-primary" />
              </div>
              <h3 className="font-semibold text-lg mb-2 text-foreground">
                {feature.title}
              </h3>
              <p className="text-sm text-muted-foreground">
                {feature.description}
              </p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
