import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Gift, Sparkles } from "lucide-react";

export default function BonusOffer() {
  return (
    <section className="py-20 bg-gradient-to-b from-card to-background">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <Card className="relative overflow-hidden border-accent border-2">
            <div className="absolute top-0 right-0 w-32 h-32 bg-accent/10 rounded-full blur-3xl" />
            <div className="absolute bottom-0 left-0 w-40 h-40 bg-accent/10 rounded-full blur-3xl" />
            
            <div className="relative p-8 md:p-12 text-center">
              <Badge 
                className="mb-6 text-lg px-6 py-2 bg-accent text-accent-foreground border-accent-border"
                data-testid="badge-bonus"
              >
                <Sparkles className="w-5 h-5 mr-2 inline" />
                BÔNUS EXCLUSIVO
              </Badge>
              
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-accent/20 mb-6">
                <Gift className="w-10 h-10 text-accent-foreground" />
              </div>

              <h2 
                className="font-serif text-3xl md:text-4xl font-bold text-primary mb-4"
                data-testid="text-bonus-title"
              >
                Mini E-book de Embalagens Natalinas Profissionais
              </h2>
              
              <p className="text-lg text-muted-foreground mb-6">
                Aprenda a criar embalagens elegantes e profissionais para suas receitas natalinas. 
                Perfeito para quem quer vender ou presentear com estilo!
              </p>

              <div className="inline-block bg-accent/10 rounded-lg px-6 py-3">
                <p className="text-accent-foreground font-semibold">
                  + Modelos prontos para impressão
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
}
