import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import dessertImage from "@assets/generated_images/Christmas_dessert_recipe_preview_e08ca5c2.png";
import turkeyImage from "@assets/generated_images/Christmas_turkey_recipe_preview_e10d329a.png";
import cookiesImage from "@assets/generated_images/Christmas_cookies_recipe_preview_7eb61128.png";

export default function RecipePreview() {
  const recipes = [
    {
      title: "Pavê de Natal Gourmet",
      image: dessertImage,
      category: "Sobremesas",
      ingredients: ["Creme de leite", "Chocolate", "Frutas vermelhas", "Biscoito champagne"]
    },
    {
      title: "Peru Assado Tradicional",
      image: turkeyImage,
      category: "Prato Principal",
      ingredients: ["Peru", "Ervas finas", "Manteiga", "Alho", "Limão"]
    },
    {
      title: "Biscoitos Decorados",
      image: cookiesImage,
      category: "Doces",
      ingredients: ["Farinha", "Açúcar", "Manteiga", "Ovos", "Glacê"]
    }
  ];

  return (
    <section className="py-20 bg-card">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 
            className="font-serif text-4xl md:text-5xl font-bold text-primary mb-4"
            data-testid="text-preview-title"
          >
            Prévia do Conteúdo
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Confira algumas das incríveis receitas que você vai aprender
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {recipes.map((recipe, index) => (
            <Card 
              key={index}
              className="overflow-hidden hover-elevate"
              data-testid={`card-recipe-${index}`}
            >
              <div className="relative h-64 bg-muted overflow-hidden">
                <img 
                  src={recipe.image} 
                  alt={recipe.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-0 left-0 right-0 h-12 bg-gradient-to-r from-[#165B33] to-[#1a7040] flex items-center px-4">
                  <Badge variant="secondary" className="bg-white text-foreground">
                    {recipe.category}
                  </Badge>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="font-serif text-2xl font-bold text-primary mb-4">
                  {recipe.title}
                </h3>
                
                <div className="bg-accent/20 border-2 border-accent rounded-md p-4">
                  <h4 className="font-semibold text-accent-foreground mb-2 flex items-center gap-2">
                    <span className="text-lg">✨</span>
                    Ingredientes
                  </h4>
                  <ul className="text-sm space-y-1">
                    {recipe.ingredients.map((ingredient, i) => (
                      <li key={i} className="text-foreground">• {ingredient}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
