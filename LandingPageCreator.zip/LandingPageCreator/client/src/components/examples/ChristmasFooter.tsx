import ChristmasFooter from '../ChristmasFooter';

export default function ChristmasFooterExample() {
  return <ChristmasFooter />;
}
