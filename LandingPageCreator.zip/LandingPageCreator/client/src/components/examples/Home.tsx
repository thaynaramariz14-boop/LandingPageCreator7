import Home from '../../pages/home';

export default function HomeExample() {
  return <Home />;
}
