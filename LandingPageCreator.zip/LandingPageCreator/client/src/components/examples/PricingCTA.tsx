import PricingCTA from '../PricingCTA';

export default function PricingCTAExample() {
  return <PricingCTA />;
}
