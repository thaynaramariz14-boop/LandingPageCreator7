import RecipePreview from '../RecipePreview';

export default function RecipePreviewExample() {
  return <RecipePreview />;
}
