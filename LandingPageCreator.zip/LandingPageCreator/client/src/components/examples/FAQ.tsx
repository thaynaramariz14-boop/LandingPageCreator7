import FAQ from '../FAQ';

export default function FAQExample() {
  return <FAQ />;
}
