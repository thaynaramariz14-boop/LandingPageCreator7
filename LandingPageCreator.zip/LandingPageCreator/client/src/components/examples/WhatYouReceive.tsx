import WhatYouReceive from '../WhatYouReceive';

export default function WhatYouReceiveExample() {
  return <WhatYouReceive />;
}
