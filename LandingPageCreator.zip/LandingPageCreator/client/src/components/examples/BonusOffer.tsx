import BonusOffer from '../BonusOffer';

export default function BonusOfferExample() {
  return <BonusOffer />;
}
