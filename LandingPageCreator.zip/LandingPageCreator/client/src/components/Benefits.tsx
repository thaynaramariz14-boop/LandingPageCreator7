import { Card } from "@/components/ui/card";
import { CheckCircle2 } from "lucide-react";

export default function Benefits() {
  const benefits = [
    "Aprenda receitas tradicionais e gourmet de Natal",
    "Ideal para vender ou preparar sua própria ceia",
    "Fotos profissionais e passo a passo detalhado",
    "Receitas fáceis, perfeitas para iniciantes",
    "Opções veganas, doces e salgadas para todos",
    "Impressões e dicas de apresentação"
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 
              className="font-serif text-4xl md:text-5xl font-bold text-primary mb-4"
              data-testid="text-benefits-title"
            >
              Por que escolher este e-book?
            </h2>
          </div>

          <Card className="p-8 md:p-12">
            <div className="grid md:grid-cols-2 gap-6">
              {benefits.map((benefit, index) => (
                <div 
                  key={index}
                  className="flex items-start gap-3"
                  data-testid={`benefit-item-${index}`}
                >
                  <CheckCircle2 className="w-6 h-6 text-[#165B33] flex-shrink-0 mt-1" />
                  <p className="text-foreground text-lg">
                    {benefit}
                  </p>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
}
