import HeroSection from "@/components/HeroSection";
import WhatYouReceive from "@/components/WhatYouReceive";
import RecipePreview from "@/components/RecipePreview";
import Benefits from "@/components/Benefits";
import FAQ from "@/components/FAQ";
import PricingCTA from "@/components/PricingCTA";
import ChristmasFooter from "@/components/ChristmasFooter";

export default function Home() {
  return (
    <div className="min-h-screen">
      <HeroSection />
      <WhatYouReceive />
      <RecipePreview />
      <Benefits />
      <FAQ />
      <PricingCTA />
      <ChristmasFooter />
    </div>
  );
}
